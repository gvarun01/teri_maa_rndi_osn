# Networking
- If user type anything without his turn then that input will taken as input when his turn arives.
-![tcp1](/mini-project-2-Mehul022/networks/tcpnetwork1.png)
-![tcp2](/mini-project-2-Mehul022/networks/tcpnetwork2.png)
-![tcp3](/mini-project-2-Mehul022/networks/tcpnetwork3.png)
-![tcp4](/mini-project-2-Mehul022/networks/tcpnetwork4.png)

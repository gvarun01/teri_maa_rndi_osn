#ifndef HEADER_H
#define HEADER_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <asm-generic/socket.h>
#include <pthread.h>
#include <signal.h>
#include <sys/wait.h>
#define BUFFER_SIZE 1024
#endif